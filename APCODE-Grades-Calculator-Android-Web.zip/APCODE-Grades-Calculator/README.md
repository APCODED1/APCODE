# APCODE Grades Calculator

Portable source project for the APCODE Grades Calculator, prepared for both:
- a public online website using GitHub Pages
- an installable Android APK built automatically by GitHub Actions

The project is based on the source snapshot supplied by the owner. The existing React + TypeScript calculator UI and grading logic are retained, with Capacitor and GitHub Actions workflows added.

## Included features
- Department selection and course lists
- Editable course code, course title, units, and scores
- Semester GPA and level CGPA calculations
- Grade scale selection and classifications
- Result report, print/PDF, and PNG report actions
- Local browser/device history and theme preference
- Mobile-responsive interface
- GitHub Pages deployment workflow
- Android debug APK build workflow

## Upload this project to GitHub from your phone
1. Download and extract this ZIP.
2. Open `https://github.com/APCODED1/APCODE` and sign in.
3. If that repository already contains files, do not delete them blindly. Back them up first or upload this project into a new branch.
4. Upload the *contents* of the `APCODE-Grades-Calculator` folder to the repository root. Include the hidden `.github` folder and its workflow files.
5. Commit the changes to `main` (or `master`, matching the workflow branch).
6. In GitHub, open **Settings → Pages** and set the build/deployment source to **GitHub Actions**.
7. Open the **Actions** tab. The web deployment and Android APK workflows should run after a push. You can also run each workflow manually using **Run workflow**.

## Get the online app
After the `Deploy APCODE web app to GitHub Pages` workflow succeeds, open the website URL shown in the workflow's deployment/environment result. The exact URL depends on your GitHub account and repository settings.

## Get the Android APK
1. Open the repository's **Actions** tab.
2. Select **Build APCODE Android APK**.
3. Open the latest successful run.
4. Scroll to **Artifacts** and download `apcode-grades-calculator-debug-apk`.
5. Extract the downloaded artifact ZIP on your Android phone, then tap `app-debug.apk` to install it. Android may ask you to allow installation from that source.
6. This is a debug APK for testing and personal installation, not a Play Store release-signed APK.

## Build locally (optional)
Requires Node.js 22 and Java/Android SDK for APK builds.

```bash
npm install
npm run build
npm run dev
```

To generate the Android project locally after installing Android Studio and its SDK:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

## Important limitations to understand
- The supplied source snapshot's analytics backend uses the AppDeploy SDK. GitHub Pages is static hosting and does not run that backend. In this portable build, calculator operations, print/PNG actions, and saved history work on the device, but live cross-device visitor analytics and the private admin statistics require a separately deployed backend.
- History is stored locally in the browser/device and is not automatically synchronized between the website and the APK.
- Confirm grading bands and course catalogues with your institution before using reports as official academic records.
- The APK workflow builds a debug APK automatically; it does not create a Play Store release package.

## Project layout
- `src/` React application and styles
- `public/resources/` logo asset
- `backend/` original AppDeploy analytics backend source, retained for reference
- `.github/workflows/deploy-pages.yml` website deployment
- `.github/workflows/build-android-apk.yml` Android APK build
- `capacitor.config.json` Android wrapper configuration
