import { Shield, Info } from 'lucide-react';

export default function AdminGate() {
  return (
    <section className="adminGate">
      <div className="eyebrow">ADMIN ANALYTICS</div>
      <h2><Shield size={20} style={{ verticalAlign: 'middle', marginRight: 8 }} />Admin dashboard</h2>
      <p>
        The calculator runs independently on GitHub Pages and Android. Live visitor counts,
        report history across devices, and owner-only analytics require a connected backend.
      </p>
      <div className="empty" role="note">
        <Info size={18} style={{ verticalAlign: 'middle', marginRight: 8 }} />
        This portable build keeps calculations and saved history on this device. Connect a
        backend before relying on shared analytics or private admin statistics.
      </div>
    </section>
  );
}
