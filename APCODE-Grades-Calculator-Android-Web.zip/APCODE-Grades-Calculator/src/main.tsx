import { Component, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';

class AppErrorBoundary extends Component<{children:ReactNode},{failed:boolean;message:string}> {
  state = { failed: false, message: '' };
  static getDerivedStateFromError(error: Error) {
    return { failed: true, message: error?.message || 'Unknown startup error' };
  }
  render() {
    if (this.state.failed) {
      return <div className="fatal"><div className="fatalCard"><b>APCODE</b><h1>APCODE could not start</h1><p>{this.state.message}</p><button onClick={() => { try { localStorage.clear(); } catch {} window.location.reload(); }}>Clear saved data &amp; Reload</button></div></div>;
    }
    return this.props.children;
  }
}
const root = document.getElementById('root');
if (root) createRoot(root).render(<AppErrorBoundary><App /></AppErrorBoundary>);